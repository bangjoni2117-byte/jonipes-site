import Head from "next/head";
import GameCard from "../components/GameCard";

const GAMES = [
  { title: "eFootball Mobile", studio: "Konami", slug: "efootball" },
  { title: "PUBG Mobile", studio: "Tencent", slug: "pubg" },
  { title: "Mobile Legends", studio: "Moonton", slug: "mobile-legends" },
  { title: "Free Fire", studio: "Garena", slug: "free-fire" },
];

export default function Home() {
  return (
    <div className="min-h-screen p-6">
      <Head>
        <title>JONI PES</title>
        <meta name="viewport" content="initial-scale=1.0, width=device-width" />
      </Head>

      <header className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 rounded-full bg-purple-800 flex items-center justify-center text-white font-bold">
          JP
        </div>
        <div>
          <div className="text-white text-sm uppercase">SITE</div>
          <div className="text-white text-2xl font-bold">JONI PES</div>
        </div>
      </header>

      <main>
        <section className="bg-purple-800 rounded-xl p-6 mb-8">
          <h1 className="text-4xl font-extrabold text-white mb-2">
            Temukan Game
            <br />
            Favoritmu
          </h1>
          <p className="text-gray-200">
            Site game vibe — cepat, aman, support All Android & Store Account
          </p>
        </section>

        <h2 className="text-white text-2xl font-bold mb-4">Populer Game</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {GAMES.map((g) => (
            <GameCard
              key={g.slug}
              title={g.title}
              studio={g.studio}
              slug={g.slug}
            />
          ))}
        </div>
      </main>
    </div>
  );
}