import { useRouter } from "next/router";
import { useState, useEffect } from "react";
import Link from "next/link";

const GAME_META = {
  "efootball": { title: "eFootball Mobile", studio: "Konami" },
  "pubg": { title: "PUBG Mobile", studio: "Tencent" },
  "mobile-legends": { title: "Mobile Legends", studio: "Moonton" },
  "free-fire": { title: "Free Fire", studio: "Garena" },
};

export default function GamePage() {
  const router = useRouter();
  const { slug } = router.query;
  const [tab, setTab] = useState("config");

  useEffect(() => {
    if (!router.isReady) return;
    const qtab = router.query.tab;
    if (qtab === "stok") setTab("stok");
    else setTab("config");
  }, [router.isReady]);

  if (!slug) return null;
  const meta = GAME_META[slug] || { title: slug };

  return (
    <div className="min-h-screen p-6 bg-gradient-to-b from-purple-800 to-purple-900 text-white">
      <div className="max-w-3xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <div className="text-sm opacity-90">{meta.studio}</div>
            <div className="text-3xl font-bold">{meta.title}</div>
          </div>
          <div className="space-x-2">
            <button
              onClick={() => window.close()}
              className="px-3 py-2 bg-purple-700 rounded"
            >
              Tutup
            </button>
            <Link href="/">
              <span className="px-3 py-2 bg-purple-600 rounded cursor-pointer">
                Kembali
              </span>
            </Link>
          </div>
        </header>

        <div className="bg-purple-900 rounded-xl p-4">
          <div className="flex gap-3 mb-4">
            <button
              onClick={() => setTab("config")}
              className={`px-4 py-2 rounded ${
                tab === "config"
                  ? "bg-yellow-400 text-purple-900 font-semibold"
                  : "bg-purple-700 text-white"
              }`}
            >
              CONFIG
            </button>
            <button
              onClick={() => setTab("stok")}
              className={`px-4 py-2 rounded ${
                tab === "stok"
                  ? "bg-yellow-400 text-purple-900 font-semibold"
                  : "bg-purple-700 text-white"
              }`}
            >
              STOK AKUN
            </button>
          </div>

          <div className="p-4 bg-purple-800 rounded">
            {tab === "config" ? (
              <div>
                <h3 className="font-bold text-xl mb-2">
                  CONFIG untuk {meta.title}
                </h3>
                <p className="text-gray-200 mb-4">
                  Di bagian CONFIG kamu bisa meletakkan panduan instal, setting,
                  atau file konfigurasi yang pengguna bisa unduh.
                </p>
                <ul className="space-y-2">
                  <li className="p-3 bg-purple-700 rounded">
                    • Contoh setelan 1: config-1.cfg
                  </li>
                  <li className="p-3 bg-purple-700 rounded">
                    • Contoh setelan 2: config-2.cfg
                  </li>
                </ul>
              </div>
            ) : (
              <div>
                <h3 className="font-bold text-xl mb-2">
                  STOK AKUN — {meta.title}
                </h3>
                <p className="text-gray-200 mb-4">
                  Daftar akun tersedia (contoh dummy).
                </p>

                <div className="grid gap-3">
                  <div className="p-3 bg-purple-700 rounded flex justify-between items-center">
                    <div>
                      <div className="font-semibold">Akun #001</div>
                      <div className="text-sm text-gray-300">
                        Level 45 • Skin rare
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        navigator.clipboard.writeText("Akun#001: user001/pass123")
                      }
                      className="px-3 py-1 rounded bg-yellow-400 text-purple-900"
                    >
                      Salin
                    </button>
                  </div>

                  <div className="p-3 bg-purple-700 rounded flex justify-between items-center">
                    <div>
                      <div className="font-semibold">Akun #002</div>
                      <div className="text-sm text-gray-300">
                        Level 32 • Skin epic
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        navigator.clipboard.writeText("Akun#002: user002/pass456")
                      }
                      className="px-3 py-1 rounded bg-yellow-400 text-purple-900"
                    >
                      Salin
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}